/*Variables are non-volatile as they are explicitly refreshed using the SPI command interface.*/

/*Definition of the Joystick structure.*/
typedef struct {
	volatile unsigned int write_command;
	volatile unsigned int x_position;
	volatile unsigned int y_position;
	volatile unsigned int status;
	volatile unsigned int control;
} JSTK;


void jstkWaitForCmd(JSTK* j);

void jstkSendPositionCmd(JSTK* j);

//AHB addresses of the Joysticks.

#define AHB_JSTK1_BASE		0x55000000		//16MB for JSTK1
#define AHB_JSTK2_BASE		0x56000000  	//16MB for JSTK2

//Create the two Joystick objects.

#define JOYSTICK_1		((JSTK *) AHB_JSTK1_BASE)
#define JOYSTICK_2		((JSTK *) AHB_JSTK2_BASE) 

//SPI commands defined in the JSTK2 datasheet.

#define CMD_GET_POSITION 	0x000000C0
