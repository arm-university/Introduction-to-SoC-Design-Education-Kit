
#include "jstk_driver.h"
#include "EDK_CM0.h"
#include <string.h>
#include "edk_driver.h"
#include "edk_api.h"

//////////////////////////////////
//
// Function waits for ongoing JSTK command to complete.
//
// Should be called OUTSIDE of the send commands to double the bandwidth of the two joysticks.
//
//////////////////////////////////
void jstkWaitForCmd(JSTK* j) {
	int read_control;
	//Manual 15us delay
	int refValue = TIMER->CURVALUE;
	int newVal = 0;
	do {
		newVal = TIMER->CURVALUE;
	} while (refValue - newVal < 49);
	//Get the status of the ongoing SPI command.
	//If control[1] == 0, the ongoing command is complete/no outgoing command.
	do {
		read_control = j->control;
		read_control = read_control & 0x00000002;
	} while(read_control == 0x00000002);
}

//////////////////////////////////
//
// Function to request and retrieve the position and status of the peripheral.
//
//////////////////////////////////

void jstkSendPositionCmd(JSTK* j) {
	//Command is sent on the positive edge of j->control;
	int read_control;
	read_control = j->control;
	read_control = read_control & 0xFFFFFFFE;	//Set j->control[0] to 0.
	j->control = read_control;							
	j->write_command = CMD_GET_POSITION;		//Set the command register to the getPosition command.
	jstkWaitForCmd(j);											//Wait for the ongoing command to finish if not complete.
	read_control = read_control | 0x00000001;
	j->control = read_control; 	//Set control[0] to 1, sending the status command and starting the SPI call.
}
