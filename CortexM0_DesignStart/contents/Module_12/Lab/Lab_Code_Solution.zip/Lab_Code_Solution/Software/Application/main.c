//--------------------------------------------------------
// Application demonstrator: SNAKE game
//--------------------------------------------------------


#include "EDK_CM0.h" 
#include "core_cm0.h"
#include "edk_driver.h"
#include "edk_api.h"
#include "jstk_driver.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Maximum snake length
#define N 200							

//Game region
#define left_boundary 5
#define right_boundary 96
#define top_boundary 5
#define bottom_boundary 116
#define boundary_thick 1

#define points_to_win 30

//Global variables
//static int i;

static int gamespeed;
static int speed_table[10]={6,9,12,15,20,25,30,35,40,60};

// Structure define
struct target{
	int x;
	int y;
	int reach;
	}target;

typedef struct{
	int x[N];
	int y[N];
	int node;
	int direction;
	int gscore;
	int rscore;
	char name[6];
	char colour;
	}Snake;

Snake Snake_1;
Snake Snake_2;

//---------------------------------------------
// Game
//---------------------------------------------
	
char game_finished = 0;
	
void Display_Scores(void)
{
	printf("\n\n\n\n\n\n\n\n");
	printf("\n\n-------- EDK Demo ---------");
	printf("\n------- Snake Game --------");
	printf("\n\nEat the food = +1");
	printf("\nDeath = +5 to other snake");
	printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	printf("\nFirst to %d wins!", points_to_win);
	printf("\nScores:\n %s - %d\n %s - %d\n", Snake_1.name, Snake_1.gscore, Snake_2.name, Snake_2.gscore);
}

void Game_Init(void)
{	
	//Draw a game region
	clear_screen();
	rectangle(left_boundary,top_boundary,right_boundary,top_boundary+boundary_thick,BLUE);
	rectangle(left_boundary,top_boundary,left_boundary+boundary_thick,bottom_boundary,BLUE);
	rectangle(left_boundary,bottom_boundary,right_boundary,bottom_boundary+boundary_thick,BLUE);
	rectangle(right_boundary,top_boundary,right_boundary+boundary_thick,bottom_boundary+boundary_thick,BLUE);	

	//Initialise data
	if(game_finished != 1)
	{
		gamespeed=speed_table[0];		
		
		//Initialise timer (load value, prescaler value, mode value)
		timer_init((Timer_Load_Value_For_One_Sec/gamespeed),Timer_Prescaler,1);	
		timer_enable();
		
		target.reach=1;
		Snake_1.direction=1;
		Snake_1.x[0]=20;Snake_1.y[0]=80;
		Snake_1.x[1]=22;Snake_1.y[1]=80;
		Snake_1.node=4;
		Snake_1.rscore = 0;
		
		Snake_2.direction=1;
		Snake_2.x[0]=70;Snake_2.y[0]=40;
		Snake_2.x[1]=72;Snake_2.y[1]=40;
		Snake_2.node=4;
		Snake_2.rscore = 0;
		
		//If this is after Reset, enable the interrupt.
		if(Snake_1.gscore == 0 && Snake_2.gscore == 0)
		{
			//Print instructions
			Display_Scores();
			NVIC_EnableIRQ(Timer_IRQn);			//start timing
			NVIC_EnableIRQ(UART_IRQn);	
		}
	}
}


void Game_Close(int snakeNum){
	clear_screen();
	int i;
	for(i = 0; i < 30; i++)
	printf("%s wins!\n", (snakeNum == 1 ? Snake_1.name : Snake_2.name));
	NVIC_DisableIRQ(Timer_IRQn);			
	NVIC_DisableIRQ(UART_IRQn);
	game_finished = 1;
}

//Generate a random target using system tick as seed
void target_gen(void){
		target.x= (char)random(left_boundary+boundary_thick+1,right_boundary-2);
		target.x=target.x-target.x%2;
		delay(111*target.x);
		target.y= (char)random(top_boundary+boundary_thick+1,bottom_boundary-2);
		target.y=target.y-target.y%2;
		target.reach=0;	
}
	
void GameOver(int snakeNum){
	
	switch(snakeNum)
	{
		case 1: Snake_2.gscore = Snake_2.gscore + 5; break;
		case 2: Snake_1.gscore = Snake_1.gscore + 5; break;
	}
	
	Display_Scores();
	if(Snake_1.gscore >= points_to_win)
	{
		Game_Close(1);
	}
	else if(Snake_2.gscore >= points_to_win)
	{
		Game_Close(2);
	}
	else{
		Game_Init();
	}
}


//---------------------------------------------
// UART ISR -- used to input commands
//---------------------------------------------

void UART_ISR(void)
{	

  //key=UartGetc();	
		
}
 

//---------------------------------------------
// TIMER ISR -- used to move the snake
//---------------------------------------------


void Timer_ISR(void)
{
	
	int overlap;
	int i;
	int s1_moved = 0;
	int s2_moved = 0;
	//Update Snake direction
	//Manual 25us delay
	unsigned int refValue = TIMER->CURVALUE;
	unsigned int newVal = 0;
	do {
		newVal = TIMER->CURVALUE;
	} while (refValue - newVal < 79);
	//Get the status of the ongoing SPI command
	jstkSendPositionCmd(JOYSTICK_1);
	jstkSendPositionCmd(JOYSTICK_2);
	jstkWaitForCmd(JOYSTICK_1);
	jstkWaitForCmd(JOYSTICK_2);
	
	int ud_1 = (JOYSTICK_1->y_position>650) ? 1 :
		((JOYSTICK_1->y_position<250) ? 2 : 0);
	int lr_1 = (JOYSTICK_1->x_position>650) ? 2 :
		((JOYSTICK_1->x_position<250) ? 1 : 0);
	
	int ud_2 = (JOYSTICK_2->y_position>650) ? 2 :
		((JOYSTICK_2->y_position<250) ? 1 : 0);
	int lr_2 = (JOYSTICK_2->x_position>650) ? 1 :
		((JOYSTICK_2->x_position<250) ? 2 : 0);
	
	switch(ud_1){
		case 0: break;
		case 1: if(Snake_1.direction!=2) Snake_1.direction = 1; s1_moved = 1; break;
		case 2: if(Snake_1.direction!=1) Snake_1.direction = 2; s1_moved = 1; break;
	}
	if(s1_moved == 0)
	{
		switch(lr_1){
			case 0: break;
			case 1: if(Snake_1.direction!=4) Snake_1.direction = 3; break;
			case 2: if(Snake_1.direction!=3) Snake_1.direction = 4; break;
		}
	}
	
	switch(ud_2){
		case 0: break;
		case 1: if(Snake_2.direction!=2) Snake_2.direction = 1; s2_moved = 1; break;
		case 2: if(Snake_2.direction!=1) Snake_2.direction = 2; s2_moved = 1; break;
	}
	
	if(s2_moved == 0)
	{
		switch(lr_2){
			case 0: break;
			case 1: if(Snake_2.direction!=4) Snake_2.direction = 3; break;
			case 2: if(Snake_2.direction!=3) Snake_2.direction = 4; break;
		}
	}
		//If target is reached, generate a new one
		if(target.reach==1){

			//Generate a new target address that is not overlapped with either of the snakes
			do{
				overlap=0;
				target_gen();
				//Check Snake 1
				for(i=0;i<Snake_1.node;i++){
					if(Snake_1.x[i]==target.x&&Snake_1.y[i]==target.y){
						overlap=1;
						break;
					}
				}
				for(i=0;i<Snake_2.node;i++){
					if(Snake_2.x[i]==target.x&&Snake_2.y[i]==target.y){
						overlap=1;
						break;
					}
				}
			}while(overlap==1);
			
				
			//Draw the target
			rectangle(target.x,target.y,target.x+2,target.y+2,WHITE);
			//Update the game speed (maximum 10 levels)	
		}
		
		//Shift the snakes
		for(i=Snake_1.node-1;i>0;i--){
			Snake_1.x[i]=Snake_1.x[i-1];
			Snake_1.y[i]=Snake_1.y[i-1];
		}
		
		for(i=Snake_2.node-1;i>0;i--){
			Snake_2.x[i]=Snake_2.x[i-1];
			Snake_2.y[i]=Snake_2.y[i-1];
		}
		
		//Handle the snake directions
		switch(Snake_2.direction){
			case 1:Snake_2.x[0]+=2;break;
			case 2: Snake_2.x[0]-=2;break;
			case 3: Snake_2.y[0]-=2;break;
			case 4: Snake_2.y[0]+=2;break;
		}
		
		switch(Snake_1.direction){
			case 1:Snake_1.x[0]+=2;break;
			case 2: Snake_1.x[0]-=2;break;
			case 3: Snake_1.y[0]-=2;break;
			case 4: Snake_1.y[0]+=2;break;
		}
		
		//Detect if either of the snakes reaches the target
		if(Snake_1.x[0]==target.x&&Snake_1.y[0]==target.y){
			rectangle(target.x,target.y,target.x+2,target.y+2,BLACK);
			Snake_1.x[Snake_1.node]=-10;Snake_1.y[Snake_1.node]=-10;
			Snake_1.node++;
			target.reach=1;
			Snake_1.rscore+=1;
			Snake_1.gscore+=1;
			if (Snake_1.rscore > Snake_2.rscore && Snake_1.rscore<=10) {
				gamespeed=speed_table[Snake_1.rscore];	
				timer_init((Timer_Load_Value_For_One_Sec/gamespeed),Timer_Prescaler,1);	
				timer_enable();
			}
			Display_Scores();
		}
		
		//Detect if either of the snakes reaches the target
		if(Snake_2.x[0]==target.x&&Snake_2.y[0]==target.y){
			rectangle(target.x,target.y,target.x+2,target.y+2,BLACK);
			Snake_2.x[Snake_2.node]=-10;Snake_2.y[Snake_2.node]=-10;
			Snake_2.node++;
			target.reach=1;
			Snake_2.rscore+=1;
			Snake_2.gscore+=1;
			if (Snake_2.rscore > Snake_1.rscore && Snake_2.rscore<=10) {
				gamespeed=speed_table[Snake_2.rscore];	
				timer_init((Timer_Load_Value_For_One_Sec/gamespeed),Timer_Prescaler,1);	
				timer_enable();
			}
			Display_Scores();
		}
		
		//Detect if either snake hits itself
		for(i=3;i<Snake_1.node;i++){
			if(Snake_1.x[i]==Snake_1.x[0]&&Snake_1.y[i]==Snake_1.y[0]){
				GameOver(1);
			}
		}
		for(i=3;i<Snake_2.node;i++){
			if(Snake_2.x[i]==Snake_2.x[0]&&Snake_2.y[i]==Snake_2.y[0]){
				GameOver(2);
			}
		}
		
		//Detect if either snake hits the other - this used to be i=3!
		for(i=0;i<Snake_1.node;i++){
			if(Snake_2.x[i]==Snake_1.x[0]&&Snake_2.y[i]==Snake_1.y[0]){
				GameOver(1);
			}
		}
		for(i=0;i<Snake_2.node;i++){
			if(Snake_1.x[i]==Snake_2.x[0]&&Snake_1.y[i]==Snake_2.y[0]){
				GameOver(2);
			}
		}
		
		//Detect if either snake hits the boundry
		if(Snake_1.x[0]<left_boundary+boundary_thick||Snake_1.x[0]>=right_boundary||Snake_1.y[0]<top_boundary+boundary_thick||Snake_1.y[0]>=bottom_boundary){
				GameOver(1);
		}		
		if(Snake_2.x[0]<left_boundary+boundary_thick||Snake_2.x[0]>=right_boundary||Snake_2.y[0]<top_boundary+boundary_thick||Snake_2.y[0]>=bottom_boundary){
			GameOver(2);
		}		
		
		
		if(game_finished == 0)
		{
		//Move both snakes on the display
		for(i=0;i<Snake_1.node;i++)
			rectangle(Snake_1.x[i],Snake_1.y[i],Snake_1.x[i]+2,Snake_1.y[i]+2,Snake_1.colour);
			rectangle(Snake_1.x[Snake_1.node-1],Snake_1.y[Snake_1.node-1],Snake_1.x[Snake_1.node-1]+2,Snake_1.y[Snake_1.node-1]+2,BLACK);
		
		for(i=0;i<Snake_2.node;i++)
			rectangle(Snake_2.x[i],Snake_2.y[i],Snake_2.x[i]+2,Snake_2.y[i]+2,Snake_2.colour);
			rectangle(Snake_2.x[Snake_2.node-1],Snake_2.y[Snake_2.node-1],Snake_2.x[Snake_2.node-1]+2,Snake_2.y[Snake_2.node-1]+2,BLACK);
		}

	//Display the total distance that the snake has moved
	Display_Int_Times();
	timer_irq_clear();
}	

//---------------------------------------------
// Main Function
//---------------------------------------------


int main(void){

	//Initialise the system
	game_finished = 0;
	Snake_1.gscore = 0;
	Snake_2.gscore = 0;
	strcpy(Snake_1.name, "  RED");
  strcpy(Snake_2.name, "GREEN");
	Snake_1.colour = RED;
	Snake_2.colour = GREEN;
	SoC_init();
	Game_Init();
	char wakeup[6] = "Hello!";
	int i = 0;
	for(i = 0; i < 6; i++)
		UartPutc(wakeup[i]);
	//Go to sleep mode and wait for interrupts
	while(1)
		__WFI();	

}
